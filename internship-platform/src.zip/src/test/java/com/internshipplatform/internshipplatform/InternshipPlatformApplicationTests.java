package com.internshipplatform.internshipplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
