package com.internshipplatform.internshipplatform.entity;

public enum Role {
    STUDENT,
    COMPANY,
    ADMIN
}
