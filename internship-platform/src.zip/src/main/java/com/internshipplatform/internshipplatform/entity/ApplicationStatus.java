package com.internshipplatform.internshipplatform.entity;

public enum ApplicationStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    WITHDRAWN
}
